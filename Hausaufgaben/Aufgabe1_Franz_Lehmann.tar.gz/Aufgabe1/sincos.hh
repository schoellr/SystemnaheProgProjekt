#ifndef SINCOS_HH
#define SINCOS_HH
void sincos(int input);
#endif

